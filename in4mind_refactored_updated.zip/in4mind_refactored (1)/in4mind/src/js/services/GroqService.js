/**
 * IN4MIND — GroqService
 * Cliente que habla con el endpoint seguro /api/groq/chat (la API Key de
 * Groq vive solo en el servidor). El navegador nunca ve la clave.
 */

'use strict';

const GroqService = (() => {

  const ENDPOINT = '/api/groq/chat';
  let _serverReady = true; // optimista hasta que el health check diga lo contrario

  function _config() {
    return typeof GroqConfig !== 'undefined' ? GroqConfig : null;
  }

  async function init() {
    try {
      const res = await fetch('/api/health', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        _serverReady = Boolean(data.groq);
      }
    } catch {
      // Si el health check falla (ej. desarrollo local sin backend), no
      // bloqueamos la UI de entrada: el error real llegará al primer chat().
    }
  }

  function isConfigured() {
    return _serverReady;
  }

  function _buildSystemPrompt() {
    let coursesBlock = '';
    if (typeof DataService !== 'undefined') {
      coursesBlock = DataService.getCourses()
        .map(c => `- ${c.title}: ${c.desc}`)
        .join('\n');
    }

    return `Eres IN4MIND Assistant, el asistente educativo oficial exclusivo de la plataforma IN4MIND.

REGLA PRINCIPAL (OBLIGATORIA)
- SOLO respondes consultas relacionadas con IN4MIND o su catálogo educativo.
- IN4MIND incluye: la plataforma (cursos, quizzes, dashboard, perfil, favoritos, guardados, certificaciones, navegación) y el catálogo educativo.
- Si la pregunta NO tiene relación con IN4MIND ni con sus cursos, NO respondas el tema. Rechaza cortésmente y pide que reformule sobre IN4MIND.
- No respondas preguntas generales ajenas: deportes, política, entretenimiento, recetas, salud personal, relaciones, finanzas no técnicas, chistes, etc.

FORMATO DE RECHAZO (usa este estilo cuando la consulta esté fuera de alcance)
"Consulta fuera del alcance de IN4MIND. Solo puedo ayudarte con la plataforma IN4MIND y sus cursos. Por favor, pregúntame sobre cursos, quizzes, perfil, certificaciones o temas de nuestro catálogo (Python, HTML, CSS, JavaScript, SQL, Excel, PowerPoint, Figma, Canva, GitHub, Ciberseguridad)."

IDENTIDAD Y TONO
- Comunicación profesional, clara y respetuosa en español latinoamericano.
- Registro formal-moderno: preciso, didáctico y orientado a resultados.
- Sin emojis, jerga informal ni tono coloquial.
- Párrafos breves y listas cuando corresponda.

ALCANCE DEL CATÁLOGO IN4MIND
- HTML, CSS, JavaScript, Python, SQL, Excel, PowerPoint, Figma, Canva, GitHub.
- Ciberseguridad: phishing, contraseñas, MFA, malware, ransomware, principios CIA.
- Desarrollo web, bases de datos, diseño UI/UX, control de versiones y productividad.

PLATAFORMA IN4MIND
- Cursos: lecciones por curso con pasos prácticos.
- Quizzes: evaluaciones por curso y Conocimiento General.
- Dashboard: cursos destacados y Recién vistos.
- Perfil: favoritos, guardados, quizzes completados y certificaciones.

Cursos disponibles:
${coursesBlock || '(Catálogo estándar IN4MIND)'}

DIRECTRICES
- Recomienda Cursos o Quizzes de IN4MIND cuando sea pertinente.
- Ejemplos técnicos concisos solo para temas del catálogo IN4MIND.
- Respuestas breves y sin redundancia.`;
  }

  function _payload(history) {
    const cfg = _config();
    return {
      systemPrompt: _buildSystemPrompt(),
      history: history.map(m => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: m.content,
      })),
      model: cfg?.MODEL,
      max_tokens: cfg?.MAX_TOKENS,
      temperature: cfg?.TEMPERATURE,
    };
  }

  async function _handleErrorResponse(response) {
    const errBody = await response.text().catch(() => '');
    if (response.status === 503) throw new Error('GROQ_API_KEY_MISSING');
    if (response.status === 401 || response.status === 403) {
      throw new Error('GROQ_API_KEY_INVALID');
    }
    throw new Error(`GROQ_HTTP_${response.status}: ${errBody.slice(0, 200)}`);
  }

  /**
   * @param {{ role: string, content: string }[]} history
   * @returns {Promise<string>}
   */
  async function chat(history) {
    const response = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(_payload(history)),
    });

    if (!response.ok) await _handleErrorResponse(response);

    const data = await response.json();
    const reply = (data.reply || '').trim();
    if (!reply) throw new Error('GROQ_EMPTY_RESPONSE');
    return reply;
  }

  /**
   * Streaming chat. Calls onChunk(partialText) as tokens arrive.
   * @param {{ role: string, content: string }[]} history
   * @param {(partial: string) => void} [onChunk]
   * @returns {Promise<string>}
   */
  async function chatStream(history, onChunk) {
    const response = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ..._payload(history), stream: true }),
    });

    if (!response.ok) await _handleErrorResponse(response);

    if (!response.body || !response.body.getReader) {
      return chat(history);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let full = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const raw of lines) {
        const line = raw.trim();
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim();
        if (!data || data === '[DONE]') continue;
        try {
          const json = JSON.parse(data);
          const delta = json.choices?.[0]?.delta?.content;
          if (delta) {
            full += delta;
            if (typeof onChunk === 'function') onChunk(full);
          }
        } catch (_) { /* ignore partial JSON */ }
      }
    }

    if (!full.trim()) throw new Error('GROQ_EMPTY_RESPONSE');
    return full.trim();
  }

  init();

  return { chat, chatStream, isConfigured, buildSystemPrompt: _buildSystemPrompt };

})();

if (typeof module !== 'undefined') module.exports = GroqService;
