/**
 * IN4MIND — QuizzesController
 * Orquesta la página de Quizzes:
 *  - Renderiza el grid de tarjetas con filtros por categoría
 *  - Gestiona la vista interactiva de quiz (pregunta → feedback → siguiente)
 *  - Muestra la pantalla de resultados con revisión pregunta a pregunta
 *  - Persiste el progreso en sessionStorage
 */

'use strict';

const QuizzesController = (() => {

  // ────────────────────────────────────────────
  // Datos: banco de quizzes
  // ────────────────────────────────────────────

  /** @type {QuizDef[]} */
  const QUIZZES = [
    {
      id: 'canvas', title: 'Canvas', category: 'design',
      desc: 'Fundamentos de Diseño Digital.',
      icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968170.png',
      questions: [
        { q: '¿Qué es Canva?',
          opts: ['Un editor de video profesional', 'Una herramienta de diseño gráfico en línea', 'Un gestor de proyectos', 'Un IDE de programación'],
          ans: 1, exp: 'Canva es una plataforma de diseño gráfico que permite crear contenido visual sin conocimientos técnicos avanzados.' },
        { q: '¿Qué tipo de archivo permite exportar Canva para impresión de alta calidad?',
          opts: ['MP4', 'PDF', 'TXT', 'ZIP'],
          ans: 1, exp: 'Canva permite exportar en PDF de alta resolución, ideal para materiales de impresión profesional.' },
        { q: '¿Qué es una "plantilla" en Canva?',
          opts: ['Un diseño preconfigurado listo para personalizar', 'Un archivo de audio', 'Una hoja de cálculo', 'Un curso en línea'],
          ans: 0, exp: 'Las plantillas son diseños prediseñados por profesionales que puedes adaptar a tus necesidades.' },
      ],
    },
    {
      id: 'python', title: 'Python', category: 'programming',
      desc: 'Lógica y Automatización.',
      icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968350.png',
      questions: [
        { q: '¿Cuál es el resultado de: print(2 ** 3) en Python?',
          opts: ['5', '6', '8', '9'],
          ans: 2, exp: 'El operador ** es potenciación. 2³ = 8.' },
        { q: '¿Qué hace la función len() en Python?',
          opts: ['Convierte a texto', 'Retorna la longitud de un objeto', 'Crea una lista vacía', 'Ejecuta un loop'],
          ans: 1, exp: 'len() devuelve el número de elementos de una secuencia, como una lista o un string.' },
        { q: '¿Cómo se define una función en Python?',
          opts: ['function miFuncion():', 'def miFuncion():', 'fun miFuncion():', 'define miFuncion():'],
          ans: 1, exp: 'En Python las funciones se definen con la palabra clave "def" seguida del nombre.' },
        { q: '¿Qué tipo de dato es True en Python?',
          opts: ['str', 'int', 'bool', 'float'],
          ans: 2, exp: 'True y False son valores del tipo booleano (bool) en Python.' },
      ],
    },
    {
      id: 'excel', title: 'Excel', category: 'office',
      desc: 'Fórmulas y Funciones Clave.',
      icon: 'https://cdn-icons-png.flaticon.com/512/732/732220.png',
      questions: [
        { q: '¿Qué fórmula usas para sumar un rango de celdas en Excel?',
          opts: ['=TOTAL(A1:A10)', '=ADD(A1:A10)', '=SUM(A1:A10)', '=SUMA()'],
          ans: 2, exp: '=SUM() (o =SUMA() en español) suma todos los valores del rango indicado.' },
        { q: '¿Qué hace la función VLOOKUP (BUSCARV)?',
          opts: ['Busca un valor en una tabla y retorna uno relacionado', 'Ordena datos alfabéticamente', 'Crea gráficos automáticos', 'Borra filas duplicadas'],
          ans: 0, exp: 'BUSCARV busca un valor en la primera columna y retorna el valor correspondiente de otra columna.' },
        { q: '¿Qué símbolo se usa para anclar una celda en Excel?',
          opts: ['@', '#', '$', '&'],
          ans: 2, exp: 'El símbolo $ antes de la columna o fila ancla esa referencia al copiar la fórmula.' },
      ],
    },
    {
      id: 'html', title: 'HTML', category: 'web',
      desc: 'Arquitectura de Páginas HTML.',
      icon: 'https://cdn-icons-png.flaticon.com/512/732/732212.png',
      questions: [
        { q: '¿Qué etiqueta define el título principal visible de una página?',
          opts: ['<title>', '<head>', '<h1>', '<header>'],
          ans: 2, exp: '<h1> define el encabezado más importante del contenido visible de la página.' },
        { q: '¿Cuál es la etiqueta correcta para insertar una imagen?',
          opts: ['<image src="">', '<img src="">', '<pic href="">', '<photo>'],
          ans: 1, exp: 'La etiqueta <img> con el atributo src es la forma estándar de insertar imágenes en HTML.' },
        { q: '¿Qué significa HTML?',
          opts: ['Hyper Transfer Markup Language', 'HyperText Markup Language', 'High Text Modular Language', 'Hyperlink Text Machine Learning'],
          ans: 1, exp: 'HTML son las siglas de HyperText Markup Language, el lenguaje de marcado de la web.' },
      ],
    },
    {
      id: 'css', title: 'CSS', category: 'web',
      desc: 'Estética y Experiencia Visual.',
      icon: 'https://cdn-icons-png.flaticon.com/512/732/732190.png',
      questions: [
        { q: '¿Qué significa CSS?',
          opts: ['Cascading Style Sheets', 'Computer Style System', 'Creative Styling Script', 'Colorful Site Structure'],
          ans: 0, exp: 'CSS significa Cascading Style Sheets, el lenguaje que aplica estilos a las páginas HTML.' },
        { q: '¿Qué propiedad CSS cambia el color del texto?',
          opts: ['background-color', 'font-color', 'color', 'text-color'],
          ans: 2, exp: 'La propiedad "color" define el color del texto en CSS.' },
        { q: '¿Qué selector CSS apunta a un elemento con id="titulo"?',
          opts: ['.titulo', '>titulo', '#titulo', '@titulo'],
          ans: 2, exp: 'El selector # selecciona elementos por su atributo id único en el documento.' },
      ],
    },
    {
      id: 'github', title: 'GitHub', category: 'tools',
      desc: 'Integración y Publicación de Proyectos.',
      icon: 'https://cdn-icons-png.flaticon.com/512/25/25231.png',
      questions: [
        { q: '¿Qué comando inicializa un repositorio Git local?',
          opts: ['git start', 'git init', 'git new', 'git create'],
          ans: 1, exp: '"git init" crea un repositorio Git vacío en el directorio actual.' },
        { q: '¿Qué hace "git push"?',
          opts: ['Descarga cambios del repositorio remoto', 'Crea una nueva rama', 'Sube commits locales al repositorio remoto', 'Borra el historial'],
          ans: 2, exp: '"git push" envía los commits locales al repositorio remoto (como GitHub).' },
        { q: '¿Qué es un "pull request" en GitHub?',
          opts: ['Una solicitud para descargar el repo', 'Una propuesta para fusionar cambios de una rama a otra', 'Un error de sincronización', 'Un tipo de commit automático'],
          ans: 1, exp: 'Un pull request es una propuesta de cambios que otros colaboradores pueden revisar antes de fusionar.' },
      ],
    },
    {
      id: 'javascript', title: 'JavaScript', category: 'web',
      desc: 'Lógica y Dinamismo Web.',
      icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968292.png',
      questions: [
        { q: '¿Cómo se declara una variable en JavaScript moderno?',
          opts: ['var x = 5', 'let x = 5', 'dim x = 5', 'int x = 5'],
          ans: 1, exp: '"let" es la forma moderna de declarar variables con alcance de bloque en JavaScript.' },
        { q: '¿Qué método agrega un elemento al final de un array?',
          opts: ['.add()', '.append()', '.push()', '.insert()'],
          ans: 2, exp: '.push() agrega uno o más elementos al final de un array y retorna la nueva longitud.' },
        { q: '¿Qué hace document.getElementById("id")?',
          opts: ['Crea un nuevo elemento HTML', 'Selecciona un elemento del DOM por su id', 'Borra un elemento', 'Cambia la URL'],
          ans: 1, exp: 'getElementById() retorna el elemento cuyo atributo id coincide con el valor dado.' },
      ],
    },
    {
      id: 'powerpoint', title: 'PowerPoint', category: 'office',
      desc: 'Diseño Visual Corporativo.',
      icon: 'https://cdn-icons-png.flaticon.com/512/732/732224.png',
      questions: [
        { q: '¿Qué vista muestra todas las diapositivas en miniatura?',
          opts: ['Vista de lectura', 'Clasificador de diapositivas', 'Vista normal', 'Presentación con diapositivas'],
          ans: 1, exp: 'El Clasificador de diapositivas muestra todas las diapositivas en miniatura para reorganizarlas.' },
        { q: '¿Qué tecla inicia la presentación desde el principio?',
          opts: ['F3', 'F5', 'F7', 'Esc'],
          ans: 1, exp: 'F5 inicia la presentación desde la primera diapositiva.' },
        { q: '¿Qué es una "transición" en PowerPoint?',
          opts: ['Un cambio de fuente', 'El efecto animado entre diapositivas', 'Una fórmula de cálculo', 'Un tipo de gráfico'],
          ans: 1, exp: 'Las transiciones son efectos visuales que ocurren al pasar de una diapositiva a la siguiente.' },
      ],
    },
  ];

  /** Categorías disponibles para los filtros */
  const CATEGORIES = [
    { id: 'all',         label: 'Todos'        },
    { id: 'web',         label: 'Web'          },
    { id: 'programming', label: 'Programación' },
    { id: 'design',      label: 'Diseño'       },
    { id: 'office',      label: 'Office'       },
    { id: 'tools',       label: 'Herramientas' },
  ];

  // ────────────────────────────────────────────
  // Estado
  // ────────────────────────────────────────────
  let _activeFilter  = 'all';
  let _currentQuiz   = null;   // QuizDef en curso
  let _currentQIdx   = 0;      // índice de pregunta actual
  let _answers       = [];     // array de { correct, chosenLabel, correctLabel, q }
  let _answered      = false;  // ¿ya respondió la pregunta actual?

  // ── Progreso persistido ──
  // { [quizId]: { correct, total } }
  let _progress = {};

  function _loadProgress() {
    try {
      const raw = sessionStorage.getItem('in4mind_quiz_progress');
      if (raw) _progress = JSON.parse(raw);
    } catch (_) { _progress = {}; }
  }

  function _saveProgress(quizId, correct, total) {
    _progress[quizId] = { correct, total, pct: Math.round((correct / total) * 100) };
    try {
      sessionStorage.setItem('in4mind_quiz_progress', JSON.stringify(_progress));
    } catch (_) { /* sin storage */ }
  }

  // ────────────────────────────────────────────
  // Refs DOM
  // ────────────────────────────────────────────
  let $listView, $quizView, $resultsView;
  let $filtersWrap, $quizGrid;
  let $continueGrid;
  // quiz interactivo
  let $quizName, $quizProgLabel, $quizProgressFill;
  let $quizQuestion, $quizOptions, $quizFeedback, $btnNext;
  // resultados
  let $resPct, $resTitle, $resSub;
  let $resCorrect, $resWrong, $resTotal;
  let $reviewList;

  // ────────────────────────────────────────────
  // Helpers de render
  // ────────────────────────────────────────────

  /**
   * Retorna el porcentaje guardado de un quiz (0 si no hay).
   * @param {string} id
   * @returns {number}
   */
  function _getPct(id) {
    return _progress[id]?.pct ?? 0;
  }

  /**
   * Construye el HTML de una tarjeta de quiz.
   * @param {QuizDef} quiz
   * @param {number} delay
   * @returns {string}
   */
  function _renderCard(quiz, delay = 0) {
    const pct = _getPct(quiz.id);
    return `
      <article class="quiz-card anim-fade-up delay-${Math.min(delay + 1, 6)}"
               data-quiz-id="${quiz.id}"
               role="button" tabindex="0"
               aria-label="Iniciar quiz de ${quiz.title}">
        <div class="quiz-card__header">
          <div class="quiz-card__icon-wrap">
            <img src="${quiz.icon}" alt="${quiz.title}" loading="lazy" width="22" height="22">
          </div>
          <div>
            <h3 class="quiz-card__title">${quiz.title}</h3>
            <p class="quiz-card__desc">${quiz.desc}</p>
          </div>
        </div>
        <div>
          <div class="quiz-card__progress-bg">
            <div class="quiz-card__progress-fill" style="width:${pct}%"></div>
          </div>
          <div class="quiz-card__controls">
            <span class="quiz-card__stat">${quiz.questions.length} Preguntas</span>
            <span class="quiz-card__stat quiz-card__stat--ok">&#10003; ${pct}%</span>
            <button class="btn--quiz-start" data-quiz-id="${quiz.id}">Empezar</button>
          </div>
        </div>
      </article>`;
  }

  /**
   * Renderiza los filtros de categoría.
   */
  function _renderFilters() {
    $filtersWrap.innerHTML = CATEGORIES.map(cat => `
      <button class="quiz-filter ${cat.id === _activeFilter ? 'quiz-filter--active' : ''}"
              data-filter="${cat.id}">${cat.label}</button>
    `).join('');

    $filtersWrap.querySelectorAll('.quiz-filter').forEach(btn => {
      btn.addEventListener('click', () => {
        _activeFilter = btn.dataset.filter;
        _renderFilters();
        _renderGrid();
      });
    });
  }

  /**
   * Renderiza el grid de tarjetas según el filtro activo.
   */
  function _renderGrid() {
    const filtered = _activeFilter === 'all'
      ? QUIZZES
      : QUIZZES.filter(q => q.category === _activeFilter);

    $quizGrid.innerHTML = filtered.length
      ? filtered.map((q, i) => _renderCard(q, i)).join('')
      : `<p style="color:var(--clr-text-muted);font-size:.85rem;grid-column:1/-1">Sin resultados para este filtro.</p>`;

    // Listeners de tarjeta y botón
    $quizGrid.querySelectorAll('[data-quiz-id]').forEach(el => {
      el.addEventListener('click', e => {
        const id = e.currentTarget.dataset.quizId;
        if (id) _startQuiz(id);
      });
      el.addEventListener('keydown', e => {
        if ((e.key === 'Enter' || e.key === ' ') && e.currentTarget.dataset.quizId) {
          _startQuiz(e.currentTarget.dataset.quizId);
        }
      });
    });
  }

  /**
   * Renderiza la sección "Continuar" con los últimos quizzes incompletos.
   */
  function _renderContinue() {
    // Quizzes con progreso > 0 y < 100
    const inProgress = QUIZZES.filter(q => {
      const p = _progress[q.id];
      return p && p.pct > 0 && p.pct < 100;
    }).slice(0, 2);

    if (!inProgress.length) {
      $continueGrid.closest('.continue-section').style.display = 'none';
      return;
    }

    $continueGrid.closest('.continue-section').style.display = '';
    $continueGrid.innerHTML = inProgress.map(q => {
      const p = _progress[q.id];
      return `
        <div class="continue-card" data-quiz-id="${q.id}" role="button" tabindex="0"
             aria-label="Continuar quiz de ${q.title}">
          <div class="continue-card__left">
            <img src="${q.icon}" alt="${q.title}" width="28" height="28">
            <div>
              <div class="continue-card__title">${q.desc}</div>
              <div class="continue-card__meta">
                ${p.correct}/${p.total} Correctas &bull; ${p.pct}%
              </div>
            </div>
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
               stroke="currentColor" stroke-width="2" stroke-linecap="round"
               stroke-linejoin="round" aria-hidden="true">
            <polyline points="9 18 15 12 9 6"/>
          </svg>
        </div>`;
    }).join('');

    $continueGrid.querySelectorAll('.continue-card').forEach(card => {
      card.addEventListener('click', () => _startQuiz(card.dataset.quizId));
      card.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') _startQuiz(card.dataset.quizId);
      });
    });
  }

  // ────────────────────────────────────────────
  // Gestión de vistas
  // ────────────────────────────────────────────

  function _showListView() {
    $listView.style.display    = '';
    $quizView.classList.remove('quiz-view--visible');
    $resultsView.classList.remove('results-view--visible');
    _renderGrid();
    _renderContinue();
  }

  function _showQuizView() {
    $listView.style.display = 'none';
    $resultsView.classList.remove('results-view--visible');
    $quizView.classList.add('quiz-view--visible');
  }

  function _showResultsView() {
    $listView.style.display = 'none';
    $quizView.classList.remove('quiz-view--visible');
    $resultsView.classList.add('results-view--visible');
  }

  // ────────────────────────────────────────────
  // Lógica del quiz
  // ────────────────────────────────────────────

  /**
   * Inicia un quiz dado su id.
   * @param {string} id
   */
  function _startQuiz(id) {
    _currentQuiz = QUIZZES.find(q => q.id === id);
    if (!_currentQuiz) return;
    _currentQIdx = 0;
    _answers     = [];
    _answered    = false;
    _showQuizView();
    _renderQuestion();
  }

  /**
   * Renderiza la pregunta actual.
   */
  function _renderQuestion() {
    const quiz  = _currentQuiz;
    const total = quiz.questions.length;
    const q     = quiz.questions[_currentQIdx];
    _answered   = false;

    // Cabecera
    $quizName.textContent      = quiz.title;
    $quizProgLabel.textContent = `${_currentQIdx + 1} / ${total}`;
    $quizProgressFill.style.width = `${(_currentQIdx / total) * 100}%`;

    // Pregunta
    $quizQuestion.textContent = q.q;

    // Limpiar feedback y botón
    $quizFeedback.className = 'quiz-feedback';
    $quizFeedback.textContent = '';
    $btnNext.classList.remove('btn--quiz-next-visible');

    // Opciones
    const LETTERS = ['A', 'B', 'C', 'D'];
    $quizOptions.innerHTML = q.opts.map((opt, i) => `
      <button class="quiz-option" data-idx="${i}" aria-label="Opción ${LETTERS[i]}: ${opt}">
        <span class="quiz-option__letter">${LETTERS[i]}</span>
        <span>${opt}</span>
      </button>
    `).join('');

    $quizOptions.querySelectorAll('.quiz-option').forEach(btn => {
      btn.addEventListener('click', () => _selectAnswer(parseInt(btn.dataset.idx, 10)));
    });
  }

  /**
   * Procesa la selección de una respuesta.
   * @param {number} idx
   */
  function _selectAnswer(idx) {
    if (_answered) return;
    _answered = true;

    const q       = _currentQuiz.questions[_currentQIdx];
    const correct = idx === q.ans;

    // Guardar respuesta
    _answers.push({
      q:            q.q,
      correct,
      chosenLabel:  q.opts[idx],
      correctLabel: q.opts[q.ans],
      exp:          q.exp,
    });

    // Estilos de las opciones
    $quizOptions.querySelectorAll('.quiz-option').forEach((btn, i) => {
      btn.disabled = true;
      if (i === q.ans) btn.classList.add('quiz-option--reveal');
      if (i === idx && !correct) btn.classList.add('quiz-option--wrong');
    });

    // Feedback
    $quizFeedback.className  = `quiz-feedback quiz-feedback--${correct ? 'correct' : 'wrong'}`;
    $quizFeedback.innerHTML  = `
      <strong>${correct ? '✓ ¡Correcto!' : '✗ Incorrecto.'}</strong> ${q.exp}`;

    // Botón siguiente / ver resultados
    $btnNext.textContent = _currentQIdx < _currentQuiz.questions.length - 1
      ? 'Siguiente →'
      : 'Ver resultados →';
    $btnNext.classList.add('btn--quiz-next-visible');
  }

  /**
   * Avanza a la siguiente pregunta o muestra los resultados.
   */
  function _nextQuestion() {
    _currentQIdx++;
    if (_currentQIdx < _currentQuiz.questions.length) {
      _renderQuestion();
    } else {
      _showResults();
    }
  }

  // ────────────────────────────────────────────
  // Resultados
  // ────────────────────────────────────────────

  function _showResults() {
    const correct = _answers.filter(a => a.correct).length;
    const total   = _answers.length;
    const pct     = Math.round((correct / total) * 100);

    // Persistir progreso
    _saveProgress(_currentQuiz.id, correct, total);

    // Llenar pantalla
    $resPct.textContent   = `${pct}%`;
    $resCorrect.textContent = correct;
    $resWrong.textContent   = total - correct;
    $resTotal.textContent   = total;

    const msg = pct >= 80
      ? '¡Excelente trabajo!'
      : pct >= 50
        ? '¡Buen intento! Sigue practicando.'
        : 'Necesitas repasar este tema.';

    $resTitle.textContent = msg;
    $resSub.textContent   = `Completaste el quiz de ${_currentQuiz.title}`;

    // Revisión
    $reviewList.innerHTML = _answers.map((a, i) => `
      <div class="review-item ${a.correct ? 'review-item--ok' : 'review-item--fail'}">
        <div class="review-item__q">${i + 1}. ${a.q}</div>
        <div class="review-item__a">
          ${a.correct
            ? '✓ Correcto'
            : `✗ Tu respuesta: "${a.chosenLabel}" — Correcta: "${a.correctLabel}"`}
        </div>
      </div>
    `).join('');

    _showResultsView();
  }

  // ────────────────────────────────────────────
  // Inicialización pública
  // ────────────────────────────────────────────

  /** Punto de entrada: llama desde DOMContentLoaded. */
  function init() {
    _loadProgress();

    // Cachear DOM — vistas principales
    $listView    = document.getElementById('quizzes-list-view');
    $quizView    = document.getElementById('quizzes-quiz-view');
    $resultsView = document.getElementById('quizzes-results-view');

    // List view
    $filtersWrap  = document.getElementById('quiz-filters');
    $quizGrid     = document.getElementById('quiz-grid');
    $continueGrid = document.getElementById('quiz-continue-grid');

    // Quiz interactivo
    $quizName         = document.getElementById('quiz-active-name');
    $quizProgLabel    = document.getElementById('quiz-active-prog');
    $quizProgressFill = document.getElementById('quiz-active-progress-fill');
    $quizQuestion     = document.getElementById('quiz-active-question');
    $quizOptions      = document.getElementById('quiz-active-options');
    $quizFeedback     = document.getElementById('quiz-active-feedback');
    $btnNext          = document.getElementById('quiz-btn-next');

    // Resultados
    $resPct     = document.getElementById('results-pct');
    $resTitle   = document.getElementById('results-title');
    $resSub     = document.getElementById('results-sub');
    $resCorrect = document.getElementById('results-correct');
    $resWrong   = document.getElementById('results-wrong');
    $resTotal   = document.getElementById('results-total');
    $reviewList = document.getElementById('results-review');

    // Renderizar
    _renderFilters();
    _renderGrid();
    _renderContinue();

    // Listeners globales de la vista quiz
    document.getElementById('quiz-btn-back')
      ?.addEventListener('click', _showListView);

    $btnNext?.addEventListener('click', _nextQuestion);

    document.getElementById('results-btn-home')
      ?.addEventListener('click', _showListView);

    document.getElementById('results-btn-retry')
      ?.addEventListener('click', () => _startQuiz(_currentQuiz.id));

    // Botón "Comenzar Quiz" del banner → primer quiz
    document.getElementById('quiz-banner-btn')
      ?.addEventListener('click', () => _startQuiz(QUIZZES[0].id));
  }

  return { init };

})();
