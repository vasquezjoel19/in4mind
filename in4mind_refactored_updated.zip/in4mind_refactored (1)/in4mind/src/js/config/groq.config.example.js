/**
 * IN4MIND — Plantilla de configuración Groq (cliente)
 * La API Key NUNCA va aquí. Configúrala como variable de entorno
 * GROQ_API_KEY en Vercel (Project Settings -> Environment Variables).
 * El navegador solo habla con /api/groq/chat, que la usa en el servidor.
 */
'use strict';

const GroqConfig = {
  MODEL: 'llama-3.3-70b-versatile',
  MAX_TOKENS: 1200,
  TEMPERATURE: 0.45,
};
