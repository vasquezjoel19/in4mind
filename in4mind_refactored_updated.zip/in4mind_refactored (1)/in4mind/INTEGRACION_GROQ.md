# Integración Groq IA — IN4MIND

Guía paso a paso para activar el asistente con **Groq** en la sección **IA**.

La API Key **nunca** se coloca en el código del navegador. Vive solo en el
servidor (Vercel), como variable de entorno. El cliente habla con
`/api/groq/chat`, que reenvía la petición a Groq con la clave guardada
de forma segura.

---

## Paso 1 — Obtener API Key de Groq

1. Ingrese a **https://console.groq.com/**
2. Cree una cuenta o inicie sesión
3. Vaya a **API Keys** → **Create API Key**
4. Copie la clave (formato: `gsk_xxxxxxxx…`)

> Si esta es una clave que ya estuvo en el código fuente en algún momento,
> revóquela y genere una nueva antes de continuar — cualquier clave que
> haya circulado en un repositorio o archivo compartido debe considerarse
> comprometida.

---

## Paso 2 — Configurar la API Key en Vercel (producción)

1. Abra su proyecto en **https://vercel.com/**
2. Vaya a **Settings → Environment Variables**
3. Agregue:
   - **Name:** `GROQ_API_KEY`
   - **Value:** su clave `gsk_...`
4. Guarde y vuelva a desplegar (`Redeploy`)

---

## Paso 2b — Configurar la API Key en local (desarrollo)

Cree un archivo `.env` (basado en `.env.example`) en la raíz del proyecto
con:

```
GROQ_API_KEY=gsk_su_clave_aqui
```

Este archivo **no debe subirse a git** (ya está listado en `.gitignore`).
El servidor local (`vercel dev` o su equivalente) la lee como variable de
entorno.

---

## Paso 3 — Ejecutar la aplicación

Desde la carpeta del proyecto:

```powershell
vercel dev
```

Abra en el navegador:

```
http://localhost:3000/in4mind/ai.html
```

Recargue con **Ctrl + Shift + R** para evitar caché.

> Nota: si sirve el proyecto con `python -m http.server` (sin backend),
> `/api/groq/chat` no existirá y el chat mostrará el mensaje de "no
> configurado" — eso es correcto, ya que ese modo no ejecuta funciones
> serverless.

---

## Paso 4 — Verificar funcionamiento

| Indicador | Significado |
|-----------|-------------|
| Banner amarillo visible | `GROQ_API_KEY` aún no configurada en el servidor |
| Estado: **Conectado a Groq IA** | Integración activa |
| Respuestas detalladas con formato | Groq respondiendo correctamente |

Si la key es inválida, el asistente mostrará un mensaje de error
profesional indicando revisar la credencial.

---

## Archivos de integración

| Archivo | Función |
|---------|---------|
| `api/groq/chat.js` | Endpoint seguro — **aquí y solo aquí** se usa la API Key, vía `process.env.GROQ_API_KEY` |
| `api/health.js` | Informa al frontend si Groq está configurado, sin exponer la clave |
| `src/js/config/groq.config.js` | Solo parámetros no secretos (modelo, tokens, temperatura) |
| `src/js/config/groq.config.example.js` | Plantilla de referencia |
| `src/js/services/GroqService.js` | Cliente que llama a `/api/groq/chat` (no a Groq directamente) |
| `src/js/controllers/AIChatController.js` | Interfaz del chat |
| `src/css/ai.css` | Vista profesional tipo Gemini |
| `ai.html` | Página del asistente |

---

## Modelos disponibles

En `groq.config.js` puede cambiar `MODEL`:

| Modelo | Uso |
|--------|-----|
| `llama-3.3-70b-versatile` | Recomendado — respuestas completas |
| `llama-3.1-8b-instant` | Más rápido, respuestas más breves |

(`api/groq/chat.js` solo acepta estos dos modelos por seguridad; cualquier
otro valor recibido cae de vuelta al modelo recomendado.)

---

## Modo sin API Key (fallback)

Si `GROQ_API_KEY` no está configurada en el servidor, el chat usa
respuestas locales (`AIKnowledge.js`) con contenido básico de IN4MIND.
Para la experiencia completa con IA generativa, configure Groq como se
describe arriba.

---

## Solución de problemas

| Problema | Solución |
|----------|----------|
| No veo cambios | Ctrl + Shift + R; URL debe incluir `/in4mind/` |
| Error 401/403 | API Key incorrecta o revocada — genere una nueva en console.groq.com |
| "GROQ_API_KEY_MISSING" | Falta configurar la variable de entorno en Vercel o en `.env` local |
| CORS / red | Verifique conexión a internet |
| Respuestas informales | El system prompt fuerza tono profesional; recargue la página |

---

## Punto de integración en código

La llamada a Groq ocurre **solo en el servidor**:

```javascript
// api/groq/chat.js
fetch(GROQ_URL, {
  headers: { Authorization: `Bearer ${process.env.GROQ_API_KEY}` },
  ...
});
```

El navegador nunca ve la key: `GroqService.js` solo llama a
`/api/groq/chat` con la conversación, y ese endpoint es el único lugar
que conoce la clave real.
