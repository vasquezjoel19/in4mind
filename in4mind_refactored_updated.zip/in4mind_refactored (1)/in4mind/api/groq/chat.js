/**
 * Vercel Serverless — proxy hacia Groq. La API Key vive solo aquí
 * (process.env.GROQ_API_KEY) y nunca se envía al navegador.
 * Soporta modo normal y streaming (pass-through de Server-Sent Events).
 */
'use strict';

const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';
const ALLOWED_MODELS = new Set(['llama-3.3-70b-versatile', 'llama-3.1-8b-instant']);

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    return res.status(503).json({ error: 'GROQ_API_KEY_MISSING' });
  }

  let body = req.body;
  if (typeof body === 'string') {
    try {
      body = JSON.parse(body);
    } catch {
      return res.status(400).json({ error: 'Invalid JSON body' });
    }
  }
  body = body || {};

  const messages = [];
  if (body.systemPrompt) {
    messages.push({ role: 'system', content: String(body.systemPrompt) });
  }
  (body.history || []).forEach(item => {
    if (!item?.content) return;
    messages.push({
      role: item.role === 'assistant' ? 'assistant' : 'user',
      content: String(item.content),
    });
  });

  if (!messages.length) {
    return res.status(400).json({ error: 'Empty conversation' });
  }

  const model = ALLOWED_MODELS.has(body.model) ? body.model : 'llama-3.3-70b-versatile';
  const wantsStream = Boolean(body.stream);

  try {
    const groqRes = await fetch(GROQ_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages,
        max_tokens: body.max_tokens ?? 1200,
        temperature: body.temperature ?? 0.45,
        stream: wantsStream,
      }),
    });

    if (!groqRes.ok) {
      const errText = await groqRes.text().catch(() => '');
      return res.status(groqRes.status).json({ error: errText.slice(0, 300) });
    }

    if (!wantsStream) {
      const data = await groqRes.json();
      const reply = data.choices?.[0]?.message?.content?.trim();
      if (!reply) {
        return res.status(502).json({ error: 'GROQ_EMPTY_RESPONSE' });
      }
      return res.status(200).json({ reply });
    }

    // Pass-through streaming: forward Groq's SSE chunks as they arrive.
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const reader = groqRes.body.getReader();
    const decoder = new TextDecoder();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      res.write(decoder.decode(value, { stream: true }));
    }
    return res.end();
  } catch (err) {
    if (!res.headersSent) {
      return res.status(500).json({ error: err.message || 'GROQ_PROXY_ERROR' });
    }
    return res.end();
  }
};
