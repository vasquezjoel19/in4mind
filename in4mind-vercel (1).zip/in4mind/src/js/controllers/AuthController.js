/**
 * IN4MIND — AuthController
 * Controla toda la lógica de autenticación:
 * toggle entre login/registro, validación de formularios,
 * llamadas al DataService y redirección post-login.
 */

'use strict';

const AuthController = (() => {

  // ── Estado interno ──
  let _currentView = 'login'; // 'login' | 'register'

  // ── Referencias DOM (inicializadas en init()) ──
  let $loginView, $registerView, $leftTitle, $leftDesc;
  let $loginForm, $registerForm;
  let $loginBtn, $registerBtn;
  let $toRegister, $toLogin;
  let $loginError, $registerError;

  // ── Copy dinámico del panel izquierdo ──
  const PANEL_COPY = {
    login: {
      title: '¡Bienvenido a IN4MIND!',
      desc:  'Empieza a entender la tecnología, de forma clara y accesible.',
    },
    register: {
      title: '¡Crea tu cuenta!',
      desc:  'Únete a nuestra plataforma y descubre el mundo digital.',
    },
  };

  // ────────────────────────────────────────────
  // Utilidades
  // ────────────────────────────────────────────

  /**
   * Alterna la visibilidad del input de contraseña.
   * @param {HTMLButtonElement} btn
   */
  function _togglePassword(btn) {
    const input = btn.closest('.form-group').querySelector('input');
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    btn.querySelector('.eye-icon').innerHTML = isHidden
      ? '<path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>'
      : '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
  }

  /**
   * Muestra un error en el formulario.
   * @param {HTMLElement} el - Elemento de mensaje de error
   * @param {string} msg
   */
  function _showError(el, msg) {
    el.textContent = msg;
    el.style.display = 'block';
    el.classList.add('anim-fade-in');
  }

  /** Limpia mensajes de error. */
  function _clearErrors() {
    [$loginError, $registerError].forEach(el => {
      el.textContent = '';
      el.style.display = 'none';
    });
    document.querySelectorAll('.form-group').forEach(g => g.classList.remove('is-invalid'));
  }

  /**
   * Valida un campo requerido y marca el grupo como inválido.
   * @param {HTMLInputElement} input
   * @returns {boolean}
   */
  function _validateRequired(input) {
    if (!input.value.trim()) {
      input.closest('.form-group')?.classList.add('is-invalid');
      return false;
    }
    return true;
  }

  /**
   * Valida formato de email estrictamente:
   * - Solo caracteres ASCII imprimibles (sin emojis ni unicode raro)
   * - Formato usuario@dominio.extension
   * @param {HTMLInputElement} input
   * @returns {boolean}
   */
  function _validateEmail(input) {
    const val = input.value.trim();
    // Solo ASCII imprimible (codes 32-126), sin espacios
    const isAsciiOnly = /^[\x21-\x7E]+$/.test(val);
    // Formato estricto: letras/números/guiones/puntos @ dominio . extensión (2-10 letras)
    const isValidFormat = /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,10}$/.test(val);
    const ok = isAsciiOnly && isValidFormat;
    if (!ok) input.closest('.form-group')?.classList.add('is-invalid');
    return ok;
  }

  /**
   * Valida contraseña:
   * - Mínimo 6 caracteres
   * - Solo caracteres ASCII imprimibles (sin emojis)
   * @param {HTMLInputElement} input
   * @param {number} [min=6]
   * @returns {boolean}
   */
  function _validatePassword(input, min = 6) {
    const val = input.value;
    const isAsciiOnly = /^[\x20-\x7E]+$/.test(val);
    const isLongEnough = val.length >= min;
    const ok = isAsciiOnly && isLongEnough;
    if (!ok) input.closest('.form-group')?.classList.add('is-invalid');
    return ok;
  }

  // ────────────────────────────────────────────
  // Cambio de vista
  // ────────────────────────────────────────────

  /**
   * Alterna entre las vistas login y registro.
   * @param {'login'|'register'} view
   */
  function switchView(view) {
    _currentView = view;
    _clearErrors();

    const copy = PANEL_COPY[view];
    $leftTitle.textContent = copy.title;
    $leftDesc.textContent  = copy.desc;

    if (view === 'login') {
      $loginView.classList.remove('auth-view--hidden');
      $loginView.classList.add('auth-view--visible');
      $registerView.classList.add('auth-view--hidden');
      $registerView.classList.remove('auth-view--visible');
    } else {
      $registerView.classList.remove('auth-view--hidden');
      $registerView.classList.add('auth-view--visible');
      $loginView.classList.add('auth-view--hidden');
      $loginView.classList.remove('auth-view--visible');
    }
  }

  // ────────────────────────────────────────────
  // Submit handlers
  // ────────────────────────────────────────────

  /** Maneja el envío del formulario de login. */
  async function _handleLogin(e) {
    e.preventDefault();
    _clearErrors();

    const emailInput = $loginForm.querySelector('#login-email');
    const passInput  = $loginForm.querySelector('#login-password');

    let valid = true;
    if (!_validateRequired(emailInput) || !_validateEmail(emailInput)) valid = false;
    if (!_validatePassword(passInput)) valid = false;

    if (!valid) {
      _showError($loginError, 'Por favor corrige los campos marcados.');
      return;
    }

    // Estado de carga
    $loginBtn.disabled = true;
    $loginBtn.textContent = 'Ingresando...';

    const result = await DataService.login(emailInput.value, passInput.value);

    if (result.ok) {
      // Guardar sesión (en producción: JWT en httpOnly cookie)
      sessionStorage.setItem('in4mind_user', JSON.stringify(result.user));
      window.location.href = 'dashboard.html';
    } else {
      _showError($loginError, result.error || 'Error al iniciar sesión.');
      $loginBtn.disabled = false;
      $loginBtn.textContent = 'Inicia Sesión';
    }
  }

  /** Maneja el envío del formulario de registro. */
  async function _handleRegister(e) {
    e.preventDefault();
    _clearErrors();

    const nameInput  = $registerForm.querySelector('#reg-name');
    const emailInput = $registerForm.querySelector('#reg-email');
    const passInput  = $registerForm.querySelector('#reg-password');

    let valid = true;
    if (!_validateRequired(nameInput))                                 valid = false;
    if (!_validateRequired(emailInput) || !_validateEmail(emailInput)) valid = false;
    if (!_validatePassword(passInput, 6))                              valid = false;

    if (!valid) {
      _showError($registerError, 'Por favor completa todos los campos correctamente.');
      return;
    }

    $registerBtn.disabled = true;
    $registerBtn.textContent = 'Creando cuenta...';

    const result = await DataService.register(nameInput.value, emailInput.value, passInput.value);

    if (result.ok) {
      sessionStorage.setItem('in4mind_user', JSON.stringify(result.user));
      window.location.href = 'dashboard.html';
    } else {
      _showError($registerError, result.error || 'Error al registrarse.');
      $registerBtn.disabled = false;
      $registerBtn.textContent = 'Registrarse';
    }
  }

  // ────────────────────────────────────────────
  // Inicialización pública
  // ────────────────────────────────────────────

  /** Inicializa el controlador y asocia listeners. */
  function init() {
    // Redirigir si ya hay sesión
    const existing = sessionStorage.getItem('in4mind_user');
    if (existing) {
      window.location.href = 'dashboard.html';
      return;
    }

    // Cachear referencias DOM
    $loginView    = document.getElementById('login-view');
    $registerView = document.getElementById('register-view');
    $leftTitle    = document.getElementById('left-title');
    $leftDesc     = document.getElementById('left-desc');
    $loginForm    = document.getElementById('login-form');
    $registerForm = document.getElementById('register-form');
    $loginBtn     = document.getElementById('login-btn');
    $registerBtn  = document.getElementById('register-btn');
    $toRegister   = document.getElementById('to-register');
    $toLogin      = document.getElementById('to-login');
    $loginError   = document.getElementById('login-error');
    $registerError= document.getElementById('register-error');

    // Inicializar vista
    switchView('login');

    // Toggle de vistas
    $toRegister?.addEventListener('click', () => switchView('register'));
    $toLogin?.addEventListener('click',    () => switchView('login'));

    // Submit
    $loginForm?.addEventListener('submit',    _handleLogin);
    $registerForm?.addEventListener('submit', _handleRegister);

    // Toggles de contraseña
    document.querySelectorAll('.pwd-toggle').forEach(btn => {
      btn.addEventListener('click', () => _togglePassword(btn));
    });

    // Limpiar error al escribir
    document.querySelectorAll('.form-input').forEach(input => {
      input.addEventListener('input', () => {
        input.closest('.form-group')?.classList.remove('is-invalid');
      });
    });
  }

  return { init };

})();
