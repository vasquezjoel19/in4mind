/**
 * IN4MIND — Configuración Groq (cliente)
 * La API Key vive SOLO en el servidor (variable de entorno GROQ_API_KEY en Vercel).
 * Este archivo ya no contiene ni necesita ninguna clave.
 */
'use strict';

const GroqConfig = {
  MODEL: 'llama-3.3-70b-versatile',
  MAX_TOKENS: 1200,
  TEMPERATURE: 0.45,
};
