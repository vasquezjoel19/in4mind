/**
 * IN4MIND — Capa de Datos (Data Service)
 * Fuente de verdad central para toda la información de la aplicación.
 * En producción, estos datos vendrían de una API REST.
 */

'use strict';

const DataService = (() => {

  const COURSES = [
    { id: 'canvas',      title: 'Canvas',      desc: 'Diseño visual profesional y creación de contenido gráfico.',       icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968170.png', color: 'var(--clr-canvas)',  category: 'design',      tags: ['diseño', 'gráfico', 'canvas', 'visual'] },
    { id: 'figma',       title: 'Figma',        desc: 'Diseño de interfaces y prototipos colaborativos.',                 icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968705.png', color: 'var(--clr-figma)',   category: 'design',      tags: ['ui', 'ux', 'figma', 'prototipo'] },
    { id: 'python',      title: 'Python',       desc: 'Programación versátil para automatización y datos.',              icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968350.png', color: 'var(--clr-python)',  category: 'programming', tags: ['python', 'programación', 'scripts', 'automatización'] },
    { id: 'javascript',  title: 'JavaScript',   desc: 'Interactividad y dinamismo para la web moderna.',                 icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968292.png', color: 'var(--clr-js)',      category: 'web',         tags: ['js', 'javascript', 'web', 'frontend'] },
    { id: 'html',        title: 'HTML',         desc: 'Estructura y semántica de páginas web.',                          icon: 'https://cdn-icons-png.flaticon.com/512/732/732212.png',   color: 'var(--clr-html)',    category: 'web',         tags: ['html', 'web', 'estructura', 'marcado'] },
    { id: 'css',         title: 'CSS',          desc: 'Estilos, animaciones y diseño responsivo.',                       icon: 'https://cdn-icons-png.flaticon.com/512/732/732190.png',   color: 'var(--clr-css)',     category: 'web',         tags: ['css', 'estilos', 'web', 'diseño'] },
    { id: 'github',      title: 'GitHub',       desc: 'Control de versiones y colaboración en proyectos.',               icon: 'https://cdn-icons-png.flaticon.com/512/25/25231.png',     color: 'var(--clr-github)',  category: 'tools',       tags: ['github', 'git', 'versiones', 'repositorio'] },
    { id: 'excel',       title: 'Excel',        desc: 'Gestión y análisis de datos con hojas de cálculo.',               icon: 'https://cdn-icons-png.flaticon.com/512/732/732220.png',   color: 'var(--clr-excel)',   category: 'office',      tags: ['excel', 'datos', 'fórmulas', 'tablas'] },
    { id: 'powerpoint',  title: 'PowerPoint',   desc: 'Presentaciones visuales de impacto corporativo.',                 icon: 'https://cdn-icons-png.flaticon.com/512/732/732224.png',   color: 'var(--clr-pptx)',    category: 'office',      tags: ['powerpoint', 'presentaciones', 'slides'] },
    { id: 'sql',         title: 'SQL',          desc: 'Consultas y gestión de bases de datos relacionales.',             icon: 'https://cdn-icons-png.flaticon.com/512/4248/4248443.png', color: 'var(--clr-sql)',     category: 'data',        tags: ['sql', 'bases de datos', 'consultas', 'datos'] },
  ];

  const RECENT_ITEMS = [
    { id: 'r1', title: 'Bases de Python',     subtitle: 'Fundamentos',          timeLabel: 'Visto hace 2 min' },
    { id: 'r2', title: 'Iniciando Canvas',    subtitle: 'Uso básico',           timeLabel: 'Hace 15 min'     },
    { id: 'r3', title: 'Principios de Excel', subtitle: 'Funciones esenciales', timeLabel: 'Hace 1 hora'     },
    { id: 'r4', title: 'Lógica de Prog.',     subtitle: 'Introducción',         timeLabel: 'Ayer'            },
  ];

  const NAV_ITEMS = [
    { id: 'home',      label: 'Inicio',     icon: 'home' },
    { id: 'tutorials', label: 'Tutoriales', icon: 'book' },
    { id: 'quizzes',   label: 'Quizzes',    icon: 'quiz' },
    { id: 'ai',        label: 'IA',         icon: 'bot'  },
  ];

  const NAV_FOOTER = [
    { id: 'settings', label: 'Ajustes', icon: 'settings' },
    { id: 'other',    label: 'Otros',   icon: 'more'     },
  ];

  // ── Almacén temporal de usuarios registrados en la sesión ──
  const _users = {};

  function getCourses(query = '') {
    if (!query.trim()) return COURSES;
    const q = query.toLowerCase();
    return COURSES.filter(c =>
      c.title.toLowerCase().includes(q) ||
      c.desc.toLowerCase().includes(q)  ||
      c.tags.some(t => t.includes(q))
    );
  }

  function getCoursesByCategory(category) {
    return COURSES.filter(c => c.category === category);
  }

  function getRecentItems() { return RECENT_ITEMS; }
  function getNavItems()    { return NAV_ITEMS;    }
  function getNavFooter()   { return NAV_FOOTER;   }

  /**
   * Simula login. Busca al usuario registrado en memoria o acepta cualquier
   * credencial válida (demo). El name siempre viene del registro, nunca del email.
   */
  function login(email, password) {
    return new Promise(resolve => {
      setTimeout(() => {
        if (!email || password.length < 6) {
          resolve({ ok: false, error: 'Credenciales inválidas.' });
          return;
        }
        // Si el usuario se registró en esta sesión, usar su nombre real
        const registered = _users[email.toLowerCase()];
        if (registered) {
          if (registered.password !== password) {
            resolve({ ok: false, error: 'Contraseña incorrecta.' });
            return;
          }
          resolve({ ok: true, user: { name: registered.name, email } });
        } else {
          // Demo: cualquier email+contraseña válidos accede
          resolve({ ok: true, user: { name: email.split('@')[0], email } });
        }
      }, 800);
    });
  }

  /**
   * Simula registro. Guarda usuario en memoria para que el login lo encuentre.
   */
  function register(name, email, password) {
    return new Promise(resolve => {
      setTimeout(() => {
        if (!name || !email || password.length < 6) {
          resolve({ ok: false, error: 'Por favor completa todos los campos.' });
          return;
        }
        // Guardar en memoria para que login lo recupere
        _users[email.toLowerCase()] = { name, password };
        resolve({ ok: true, user: { name, email } });
      }, 800);
    });
  }

  return { getCourses, getCoursesByCategory, getRecentItems, getNavItems, getNavFooter, login, register };

})();

if (typeof module !== 'undefined') module.exports = DataService;
